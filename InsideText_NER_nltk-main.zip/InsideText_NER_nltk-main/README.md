# InsideText_NER
Named Entity Recognition 
